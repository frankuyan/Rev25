#include <stdio.h>
int nasum(int a, int b);
int main()
{
  printf("%d\n", nasum(28,14));
  return 0;
}
